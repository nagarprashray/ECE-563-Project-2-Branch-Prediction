public class bp_params
{
    public long K;
    public long M1;
    public long M2;
    public long N;
    String      bp_name;
}
